var searchData=
[
  ['guess',['Guess',['../structGuess.html',1,'']]]
];
