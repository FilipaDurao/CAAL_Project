var searchData=
[
  ['stationname',['stationName',['../structGuess.html#a971cb406490f33db34163b29cc909fc6',1,'Guess']]]
];
