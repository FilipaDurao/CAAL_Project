var searchData=
[
  ['comparedistance',['compareDistance',['../structcompareDistance.html',1,'']]]
];
