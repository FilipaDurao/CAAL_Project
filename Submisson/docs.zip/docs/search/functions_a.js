var searchData=
[
  ['node',['Node',['../classNode.html#aa9d75638eabc15e584b829b6a1673da6',1,'Node::Node(const T &amp;value, unsigned int ID)'],['../classNode.html#a4406e06c6191902e8fced1ba32e1b0aa',1,'Node::Node(const T &amp;value, unsigned int ID, int x, int y)']]]
];
